# GBA Falling Apple Game

This is a simple mGBA game where the player controls a basket to catch falling apples and earn points.

## Controls

- **Arrow Keys** – Move the basket.
- **Start (Enter)** – Start the game from the title screen.
- **Select (Backspace)** – Fully reset the game at any time (including high score, score, and state).

## Goal

Catch as many apples as possible before one hits the ground. If an apple reaches the bottom of the screen, the game ends. 

If at any time you want to restart everything from scratch, press the backspace key.