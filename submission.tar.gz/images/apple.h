/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize 32x32 apple apple.png 
 * Time-stamp: Friday 04/04/2025, 19:21:27
 * 
 * Image Information
 * -----------------
 * apple.png 32@32
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef APPLE_H
#define APPLE_H

extern const unsigned short apple[1024];
#define APPLE_SIZE 2048
#define APPLE_LENGTH 1024
#define APPLE_WIDTH 32
#define APPLE_HEIGHT 32

#endif

