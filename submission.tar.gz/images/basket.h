/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize 32x16 basket basket.png 
 * Time-stamp: Friday 04/04/2025, 19:25:20
 * 
 * Image Information
 * -----------------
 * basket.png 32@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BASKET_H
#define BASKET_H

extern const unsigned short basket[512];
#define BASKET_SIZE 1024
#define BASKET_LENGTH 512
#define BASKET_WIDTH 32
#define BASKET_HEIGHT 16

#endif

